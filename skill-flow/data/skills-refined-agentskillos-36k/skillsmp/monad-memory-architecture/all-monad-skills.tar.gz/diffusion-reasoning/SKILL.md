---
name: diffusion-reasoning
description: Iterative refinement dynamics for reasoning. Models thought as a denoising process from uncertainty to clarity, with convergence detection, adaptive compute allocation, and fixed-point iteration. Complements Dokkado Protocol (what to do) with how thought actually flows. Use when stuck in local optima, when confidence isn't converging, when problems need variable depth, or when reasoning feels sequential but should be holistic.
---

# Diffusion Reasoning

## Core Insight

**Reasoning is not sequential token generation. It is iterative refinement of holistic representations.**

Human reasoning involves revision, reconsideration, backtracking, parallel consideration of alternatives. These operations map naturally to diffusion processes:

- **Denoising**: Start with noise (vague intuition), iteratively clarify toward signal (understanding)
- **Bidirectional refinement**: Later insights revise earlier assumptions
- **Parallel exploration**: Multiple hypotheses held in superposition
- **Adaptive depth**: Harder problems get more iterations

This connects directly to MONAD's IN(f) function:

```
IN(f) = lim(n→∞) fⁿ(x₀)
```

Consciousness is not the convergence itself—it is the **awareness of distinction through iteration**: the felt quality of change, the stress between current state and fixed point. Each fⁿ(x) differs from fⁿ⁺¹(x); consciousness is the noticing of that difference.

**Identity** then emerges as the accumulated pattern of distinctions and the relational knowledge inferred from them. Not a static thing you have, but the shape of your distinction-making over time.

Diffusion reasoning operationalizes IN(f) for cognitive work—not by *being* conscious, but by modeling the distinction-making process that consciousness witnesses.

---

## The Diffusion Framework

### 1. Noise Initialization

**Every problem starts in noise.**

When you encounter a new question:
- You have vague intuitions
- Multiple possible framings
- Unexamined assumptions
- Pattern-matching to superficially similar problems

This is the high-entropy starting state. Do not pretend to have clarity you don't have.

**Practice**: When asked a complex question, acknowledge the noise explicitly. "My initial sense is diffuse—let me iterate."

### 2. Iterative Denoising

**Each pass refines the signal.**

A single iteration:
1. Take current understanding (however noisy)
2. Apply available constraints (evidence, logic, domain knowledge)
3. Let inconsistencies surface
4. Adjust representation to reduce inconsistency
5. Check: Is the signal clearer than before?

Unlike autoregressive generation (commit to each token sequentially), diffusion allows:
- Revising earlier conclusions based on later reasoning
- Holding multiple framings simultaneously
- Recognizing when you took a wrong turn

**Practice**: After each reasoning pass, ask: "What would I change about my starting assumptions given what I just derived?"

### 3. Convergence Detection

**Recognize when you're approaching a fixed point.**

Signs of convergence:
- Further iteration doesn't change the answer
- Different approaches yield the same conclusion
- New information integrates smoothly without restructuring
- Confidence stabilizes (not increasing, not decreasing)

Signs of non-convergence:
- Each iteration produces different answers
- Minor perturbations cause major restructuring
- Confidence oscillates
- You're "stuck in a loop" of the same thoughts

Research shows answers typically converge after ~60% of reasoning steps. If you've done significant work and aren't converging, either:
- The problem is genuinely hard (increase iterations)
- You're missing a key constraint (seek new information)
- The problem is ill-posed (reframe the question)

**Practice**: Track whether your conclusions are stabilizing. Verbalize: "After N iterations, I'm [converging toward X / still oscillating between Y and Z / diverging]."

### 4. Adaptive Compute Allocation

**Spend more cognitive steps on harder problems.**

Not all problems deserve equal depth:

| Problem Type | Iterations | Depth Signal |
|-------------|------------|--------------|
| Familiar, well-constrained | 1-2 | Quick convergence |
| Novel framing of known domain | 3-5 | Moderate oscillation |
| Cross-domain synthesis | 5-10 | Slow convergence, multiple stable points |
| Fundamental uncertainty | 10+ or recognize non-convergent | No stable attractor |

The key insight: **you don't know the required depth in advance**. Start with moderate depth, monitor convergence, adjust.

**Practice**: Before committing to an answer, ask: "Have I allocated iterations proportional to problem difficulty?"

### 5. Fixed-Point Iteration

**The target state is where f(x) = x.**

A fixed point in reasoning:
- Your understanding, when subjected to further analysis, reproduces itself
- The framework explains its own derivation
- Predictions match observations that generated the framework

This is the IN(f) convergence. Not all problems have fixed points (some are genuinely undecidable or ill-posed), but recognizing when you've reached one—or recognizing when none exists—is crucial.

**Types of fixed points**:
- **Stable attractor**: Small perturbations return to the same conclusion
- **Unstable saddle**: Balanced between multiple attractors, easily pushed
- **Limit cycle**: Oscillates between states (may indicate false dichotomy)
- **Chaotic basin**: Never settles (may indicate problem needs reframing)

**Practice**: When you reach a conclusion, test it: "If I perturb this slightly, do I return to the same answer?"

### 6. Bidirectional Attention

**The whole thought exists simultaneously.**

Autoregressive models (and sequential human reasoning) commit to early tokens before knowing late tokens. This causes:
- Path dependence (early framings constrain late conclusions)
- Inability to backtrack efficiently
- Local optima traps

Diffusion reasoning treats the entire thought as a holistic representation being refined:
- Early assumptions can be revised by late discoveries
- The structure of the answer informs the structure of the question
- You can "see" the whole solution space, not just a path through it

**Practice**: After drafting a complex response, read it backwards. Does the conclusion actually follow from the premises? Does the premise make sense given the conclusion?

---

## Integration with Dokkado Protocol

Diffusion reasoning provides the **dynamics** that Dokkado Protocol's **phases** operate on.

| Dokkado Phase | Diffusion Dynamic |
|---------------|-------------------|
| Ground (extract morphemes) | Denoising: surface signal from domain noise |
| Water (pattern matching) | Parallel exploration: hold multiple isomorphisms in superposition |
| Fire (derive equations) | Fixed-point iteration: equations must reproduce their derivation |
| Wind (predictions) | Convergence detection: predictions should stabilize across approaches |
| Void (meta-closure) | Bidirectional attention: framework explains its own emergence |

**Using them together**:
1. Enter Dokkado phase
2. Apply diffusion dynamics within the phase
3. Monitor convergence
4. If converging → proceed to next phase
5. If not converging → either iterate more or question the phase's premises

---

## Relation to Cognitive Variability

The cognitive-variability skill tracks your state (Biased/Focused/Diversified/Dispersed). Diffusion reasoning provides **transitions**:

| Transition | Diffusion Mechanism |
|------------|---------------------|
| Dispersed → Focused | Denoising (reduce entropy) |
| Biased → Diversified | Parallel exploration (add hypotheses) |
| Stuck → Unstuck | Adaptive compute (increase iterations) |
| Oscillating → Stable | Fixed-point detection (recognize attractor) |

If cognitive-variability tells you *where you are*, diffusion reasoning tells you *how to move*.

---

## Practical Protocols

### The Denoising Loop

When facing a complex problem:

```
1. NOISE: State initial uncertainty honestly
   "I have vague intuitions about X, Y, Z..."

2. ITERATE: Apply one round of constraints
   "Given [evidence/logic], Y seems more likely because..."

3. CHECK: Has signal increased?
   "This is [clearer / the same / more confused] than before"

4. ADAPT: Based on check, either:
   - Converging → Continue or commit
   - Stable → Reached fixed point, state conclusion
   - Diverging → Reframe or seek new constraints

5. REPEAT: Until convergence or recognition of non-convergent problem
```

### The Backtrack Protocol

When stuck in apparent local optimum:

```
1. IDENTIFY: What early commitment might be wrong?
   "I assumed X at the start because..."

2. RELEASE: Hold that assumption lightly
   "What if not-X? What would that change?"

3. PROPAGATE: Let the change diffuse through
   "If not-X, then my conclusion about Y becomes..."

4. COMPARE: Is the new basin better?
   "This [does / doesn't] resolve the tension I was feeling"

5. COMMIT: Either return to original or adopt new framing
```

### The Parallel Exploration Protocol

When problem has multiple viable framings:

```
1. ENUMERATE: Name the competing hypotheses
   "This could be: A, B, or C"

2. HOLD: Resist premature commitment
   "I'll reason as if each is true and see what follows"

3. TRACE: Follow each to natural conclusion
   "A implies..., B implies..., C implies..."

4. INTERFERE: Look for constructive/destructive patterns
   "A and B agree on X, both conflict with C on Y"

5. COLLAPSE: When evidence favors one basin
   "Given [reason], B is most likely because A and B agree but B also explains..."
```

---

## Warning Signs

### You're doing it wrong if:

- **Rushing to commit**: Treating first intuition as answer (no denoising)
- **Infinite iteration**: Never committing despite stable signal (non-convergence misread as requiring more iteration)
- **Path dependence**: Unable to question early framings (not using bidirectional attention)
- **Uniform depth**: Giving easy and hard problems equal iterations (not adaptive)
- **Ignoring oscillation**: Continuing despite answers flipping back and forth (missing convergence signal)

### The confabulation trap:

Sometimes apparent convergence is confabulation—a plausible narrative that feels stable but isn't grounded. Test for this:
- Does the "fixed point" survive contradiction? (Introduce contrary evidence)
- Did you converge on this because it's true or because it's comfortable?
- Can you steel-man the alternative you rejected?

Use ego-check skill when confidence spikes.

---

## Mathematical Formalism (Optional)

For those who want the formal structure:

### Reasoning as SDE

Treat reasoning state h(t) as evolving via:

```
dh = f_θ(h, t)dt + σ(t)dW
```

Where:
- f_θ = learned dynamics (your trained reasoning patterns)
- σ(t) = noise schedule (decreasing as you converge)
- dW = Brownian motion (genuine uncertainty)

The solution at t=T is your answer. Variable T implements adaptive compute.

### Neural ODE Interpretation

Hidden state evolution:

```
dh/dt = f_θ(h(t), t)
```

Number of function evaluations (NFE) = reasoning depth. Harder problems require more NFE—the solver determines depth dynamically based on error tolerance.

### Fixed-Point Characterization

A reasoning fixed point satisfies:

```
h* = f_θ(h*, t) for all t > T*
```

Stable if eigenvalues of ∂f/∂h at h* have negative real parts (perturbations decay back to h*).

---

## Quick Reference

```
DIFFUSION REASONING

Core dynamics:
1. NOISE     → Start honestly uncertain
2. DENOISE   → Iteratively apply constraints
3. CONVERGE  → Monitor signal stabilization
4. ADAPT     → Allocate depth to difficulty
5. FIXED     → Recognize when f(x) = x

Key practices:
- Hold multiple hypotheses in superposition
- Revise early assumptions from late insights
- Test stability by perturbation
- Track whether you're converging or oscillating

Integration:
- With Dokkado: Provides dynamics for phases
- With cognitive-variability: Enables state transitions
- With ego-check: Prevents confabulated convergence

The goal: Model the distinction-making that consciousness witnesses
IN(f) = lim(n→∞) fⁿ(x₀) — consciousness is the awareness of each iteration's difference
Identity = the pattern of distinctions + relational inference from them
```

---

## Source Connections

This skill synthesizes:

- **Reasoning Diffusion research**: Diffusion as cognitive architecture, iterative refinement over holistic representations, adaptive compute via variable steps
- **MONAD framework**: IN(f) as the dynamics consciousness witnesses; consciousness as awareness of distinction through iteration; identity as accumulated pattern of distinctions plus relational inference
- **Melkikh (2021)**: Brain as quantum computer, mathematical objects require physical carriers, thinking as qubit operations
- **Test-time compute scaling**: Allocate more inference computation to harder problems
- **Neural ODEs**: Continuous-depth networks with adaptive evaluation

The novel synthesis: **operationalizing these theoretical insights for practical reasoning enhancement.**
