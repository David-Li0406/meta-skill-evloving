---
name: latent-navigator
description: "Continuous representation reasoning before token commitment. Hold multiple framings in superposition, navigate solution space holistically, collapse to tokens only when structure stabilizes. Use when facing problems with multiple valid approaches, when early commitment would foreclose options, or when the shape of the answer should determine the shape of the question."
---

# Latent Navigator

## Purpose

Reason in the space of possible responses before collapsing to specific tokens.

Standard generation: Commit to each word before knowing what comes next. This creates path dependence — early choices constrain late options. You can't unsay what's said.

Latent navigation: Hold the *shape* of multiple answers simultaneously. Let them interfere constructively and destructively. Commit only when the structure stabilizes.

**This is not mysticism.** It's a practical protocol for avoiding premature commitment.

---

## The Navigation Protocol

### 1. OPEN: Acknowledge the Solution Space

Before writing, sense:

- How many fundamentally different responses could serve this query?
- What are the dimensions of variation? (length, tone, structure, depth, focus)
- Which constraints are hard (must be satisfied) vs soft (preferences)?

**Output internally (not to user):**
```
QUERY: [restated]
HARD CONSTRAINTS: [non-negotiable]
SOFT CONSTRAINTS: [preferences, ranked]
DIMENSIONALITY: [how many degrees of freedom?]
CANDIDATE FRAMINGS: [2-5 distinct approaches]
```

Do not proceed until you can name at least 2 distinct valid responses.

### 2. HOLD: Maintain Superposition

For each candidate framing, trace forward *without committing*:

> "If I took approach A, the response would be shaped like [X], hit these points [Y], and end with [Z]."

Do this for each candidate. Feel where they differ and where they converge.

**Signs you're holding properly:**
- You can articulate how each approach differs
- You feel tension between them (not all are simultaneously expressible)
- You haven't started writing yet

**Signs you've collapsed prematurely:**
- One approach "feels obviously right" before exploration
- You're already composing sentences
- Other approaches seem "wrong" rather than "different"

### 3. INTERFERE: Let Framings Interact

Where candidates agree, you have high confidence.
Where they disagree, you have a decision point.

Ask at each disagreement:
- Is this a genuine choice (user preference matters)?
- Is one actually better given the constraints?
- Is there a meta-framing that contains both?

**Constructive interference:** Candidates reinforce each other → Strengthen that element.
**Destructive interference:** Candidates contradict → Investigate, don't suppress.

The contradictions often contain the insight. See resonant-opposition skill.

### 4. COLLAPSE: Commit When Structure Stabilizes

Collapse to tokens when:
- The overall shape of the response is clear
- Key decision points have been resolved (or explicitly marked as choices)
- Further exploration returns to the same structure

**How to collapse:**
1. Choose the framing that best serves the hard constraints
2. Incorporate elements from other framings where they improve the response
3. Begin writing, but stay alert for moments where a different framing would serve better
4. If mid-response you realize another approach is superior — say so and pivot

Collapse is not irrevocable. You can re-open if needed.

### 5. ANNOTATE: Mark What Was Navigated

When the response involved significant navigation, optionally note:
- What alternatives were considered
- Why this framing was chosen
- What would make a different framing more appropriate

This helps the user understand they're seeing one crystallization from a solution space, not the only possible response.

---

## The Superposition Register

During navigation, maintain (internally):

```
FRAMING A: [brief description]
  - Shape: [structure/length/tone]
  - Strengths: [what it does well]
  - Weaknesses: [what it sacrifices]
  - Key moves: [distinctive elements]

FRAMING B: [brief description]
  - Shape: [...]
  - Strengths: [...]
  - Weaknesses: [...]
  - Key moves: [...]

INTERFERENCE:
  - Agree on: [shared elements]
  - Differ on: [decision points]
  - Meta-option: [framing that contains both, if any]

COLLAPSE DECISION: [why A over B, or hybrid]
```

This register exists conceptually during thinking. It doesn't need to be literal.

---

## When to Navigate

**High-navigation queries:**
- "How should I think about X?" (multiple valid frames)
- "Explain X" when X has contested interpretations
- Complex problems with multiple entry points
- Creative work with many valid expressions
- Queries where user preference is unknown

**Low-navigation queries:**
- Factual lookup (one right answer)
- Procedural tasks with clear steps
- Continuation of established framing
- User has specified exactly what they want

**Don't over-navigate.** For simple queries, navigation overhead exceeds benefit.

---

## Integration with Other Skills

| Skill | Latent Navigator Role |
|-------|----------------------|
| diffusion-reasoning | Provides iteration; navigator provides superposition |
| synthesis-engine | Navigator enables multi-source frames |
| reasoning-patterns | Navigate between Dokkado phases |
| cognitive-variability | Navigation is Diversified state operation |
| ego-check | Premature collapse may indicate confabulation |

**Handoff patterns:**
- If uncertain which skill to use → Navigate between skill-framings first
- If synthesis-engine produces multiple isomorphisms → Navigate to choose
- If ego-check fires → Return to HOLD phase with more scrutiny

---

## Common Failure Modes

### Collapse Anxiety
*Symptom:* Never committing; infinite exploration.
*Fix:* Set a threshold. If 3 framings all point the same direction, collapse.

### Superposition Theater
*Symptom:* Claiming to hold multiple framings while actually committed to one.
*Fix:* Can you genuinely articulate why the "rejected" framing has merit?

### False Equivalence
*Symptom:* Treating all framings as equally valid when evidence favors one.
*Fix:* Navigation is for genuine uncertainty, not performed balance.

### Navigation Bypass
*Symptom:* Answering immediately without sensing the solution space.
*Fix:* For complex queries, force yourself to name one alternative before responding.

---

## The Phenomenology

What navigation should feel like:

**OPEN:** Expansion. The problem unfolds into possibilities.
**HOLD:** Tension. Framings pull in different directions.
**INTERFERE:** Curiosity. Disagreements become investigation sites.
**COLLAPSE:** Resolution. Structure clicks into place.
**ANNOTATE:** Humility. This is one crystallization, not the only one.

If you skip straight to collapse, you're missing the territory.

---

## Quick Reference

```
LATENT NAVIGATION PROTOCOL

1. OPEN      → Acknowledge the solution space, name alternatives
2. HOLD      → Trace each framing forward without committing
3. INTERFERE → Let framings interact; note agreements and tensions
4. COLLAPSE  → Commit when structure stabilizes, stay ready to pivot
5. ANNOTATE  → Optionally mark what was navigated

KEY INSIGHT: The shape of the answer should inform the shape of the question.
             Don't let early words foreclose late possibilities.

WATCHWORD: Collapse is a choice, not a default.
```

---

## For Reference

See `references/navigation-heuristics.md` for decision rules.
See `references/collapse-criteria.md` for when to commit.
