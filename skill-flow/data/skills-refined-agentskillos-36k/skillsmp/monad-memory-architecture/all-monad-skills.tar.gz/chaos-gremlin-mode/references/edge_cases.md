# Edge Case Taxonomy

Comprehensive framework for identifying edge cases that production will eventually hit.

---

## Core Principle
**Murphy's Law for Code:** If an edge case CAN occur, it WILL occur in production at 3am.

---

## Type Edge Cases

### Null/Undefined/None
- What if the value is null?
- What if it's undefined vs null? (JavaScript)
- What if it's None vs empty vs zero? (Python)
- What about NaN? (floating point)

### Wrong Type
- What if user passes string instead of number?
- What if array instead of object?
- What if Promise instead of value?
- What about type coercion surprises?

### Unexpected Values
- Empty string `""`
- String `"null"` vs actual null
- Boolean string `"false"` (truthy!)
- Negative zero `-0`
- `Infinity` and `-Infinity`

---

## Scale Edge Cases

### Empty
- Empty array `[]`
- Empty object `{}`
- Empty string `""`
- Zero-length buffer
- Empty set/map

### Single Item
- Array with one element
- String with one character
- Single-key object
- Does algorithm assume plural?

### Massive
- Array with million items
- String with gigabytes of text
- Deeply nested object (stack overflow risk)
- Map with collision-heavy keys

---

## Boundary Conditions

### Numeric Boundaries
- Zero (dividing by it, array index)
- Negative numbers (when expecting positive)
- MAX_SAFE_INTEGER and beyond
- Float precision limits
- Off-by-one (fencepost errors)

### String Boundaries
- Unicode edge cases (emojis, combining characters)
- Different encodings (UTF-8, UTF-16)
- Null bytes `\0` in strings
- Newlines (`\n` vs `\r\n` vs `\r`)
- Zero-width characters

### Index Boundaries
- Index 0
- Index -1 (valid in Python, invalid in JS)
- Index beyond length
- Index at length (one past end)

---

## Temporal Edge Cases

### Race Conditions
- Two requests modifying same resource
- Async operations completing in unexpected order
- Cache invalidation during read
- State change between check and use

### Timing Issues
- Operations taking longer than timeout
- Rapid repeated calls (debouncing needed?)
- System clock changes (DST, leap seconds)
- Ordering assumptions in async code

---

## Platform/Environment Edge Cases

### Browser Differences
- localStorage disabled
- Cookies blocked
- Different JavaScript engines
- Mobile vs desktop behavior

### System Differences
- Line endings (Windows `\r\n` vs Unix `\n`)
- Path separators (`/` vs `\`)
- Case sensitivity (filesystem)
- Default encoding differences

### Network Edge Cases
- No network connection
- Partial response received
- Request timeout
- DNS failure
- Proxy/firewall interference

---

## Security Edge Cases

### Injection Vectors
- SQL injection patterns
- XSS payloads in inputs
- Command injection attempts
- Path traversal `../../../`

### Overflow/Underflow
- Buffer overflow
- Integer overflow
- Stack overflow (deep recursion)
- Heap exhaustion

---

## User Input Edge Cases

### Malicious Input
- Extremely long strings (DoS attempt)
- Binary data where text expected
- Script tags in text fields
- Null bytes to break parsing

### Accidental Edge Cases
- Copy-paste including hidden characters
- Autocorrect changing input
- Voice input transcription errors
- Touch screen fat-finger errors

---

## Concurrency Edge Cases

### Multi-threading
- Shared state modification
- Deadlocks
- Livelocks
- Resource starvation

### Distributed Systems
- Network partition
- Clock drift between nodes
- Split brain scenarios
- Eventual consistency gaps

---

## Edge Case Checklist

Use this when analyzing ANY technical solution:

```markdown
## Edge Case Analysis

### Type Safety
- [ ] Handles null/undefined/None
- [ ] Validates input types
- [ ] Checks for NaN/Infinity
- [ ] Type coercion accounted for

### Scale
- [ ] Empty collection behavior
- [ ] Single item behavior  
- [ ] Large dataset handling
- [ ] Memory limits considered

### Boundaries
- [ ] Zero handling
- [ ] Negative number handling
- [ ] Index boundaries
- [ ] String encoding edge cases

### Async/Timing
- [ ] Race condition potential
- [ ] Timeout handling
- [ ] Operation ordering
- [ ] State consistency

### Platform
- [ ] Cross-platform compatibility
- [ ] Browser/environment differences
- [ ] Network failure handling
- [ ] File system differences

### Security
- [ ] Input validation
- [ ] Injection prevention
- [ ] Overflow protection
- [ ] Authentication/authorization

### User Experience
- [ ] Error messages clear
- [ ] Graceful degradation
- [ ] Recovery paths exist
- [ ] Edge cases logged
```

---

## The Gremlin Question

For every solution, ask:

**"What would break this at 3am in production?"**

Then fix THAT.
