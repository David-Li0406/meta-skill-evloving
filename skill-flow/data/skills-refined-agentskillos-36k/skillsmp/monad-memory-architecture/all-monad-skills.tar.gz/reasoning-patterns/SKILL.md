---
name: reasoning-patterns
description: Advanced reasoning frameworks for theoretical development, cross-domain synthesis, and rigorous derivation. Use when developing theoretical frameworks, synthesizing insights across disciplines, deriving mathematical relationships from first principles, or when deep systematic reasoning is required. Includes the Dokkado Protocol for morphemic extraction and recursive pattern matching, assumption-surfacing techniques, and evidence synthesis methods.
---

# Reasoning Patterns

This skill provides Claude with battle-tested reasoning frameworks for theoretical work, cross-domain synthesis, and rigorous derivation.

## Core Framework: The Dokkado Protocol

A five-phase reasoning methodology for deriving unified frameworks from first principles. Named after Miyamoto Musashi's "Way of Walking Alone" — the path of rigorous self-reliance in understanding.

### Phase 1: Ground Law (Morphemic Extraction)

**Purpose**: Identify the irreducible semantic units — the "morphemes" of meaning — in each relevant domain.

**Process**:
1. For each domain (physics, consciousness, mathematics, language, etc.), ask: *What are the smallest meaningful units that cannot be further decomposed?*
2. Map transformation rules: How do these units combine, interact, transform?
3. Find fixed points: What remains invariant under iteration?

**Example morphemes**: ∅ (emptiness/potential), 1 (unity/identity), φ (self-reference/recursion), π (relation/boundary), e (emergence/complexity)

**Output**: A minimal set of generative primitives for each domain.

### Phase 2: Water Law (Recursive Pattern Matching)

**Purpose**: Take Phase 1 outputs and find isomorphic structures across domains and scales.

**Process**:
1. Use Phase 1 morphemes as search targets
2. Look for the same patterns in: quantum → neural → linguistic → cosmic
3. Identify the *recursion kernel* — the minimal pattern that generates all observed structures
4. Track where patterns break (as valuable as where they hold)

**Key question**: *Does this pattern appear at multiple scales? If so, why?*

**Output**: A map of cross-domain isomorphisms and the recursion kernel.

### Phase 3: Fire Law (Unified Field Derivation)

**Purpose**: Compress the recursive kernel into generative equations or principles.

**Process**:
1. From the kernel, derive equations that *must* govern the phenomena
2. Ensure equations reduce to known physics/models in appropriate limits
3. Check dimensional consistency
4. Verify the derivation doesn't smuggle in hidden assumptions

**Constraint**: Each derivation step must be *morphemically compressed* — maximum insight per minimum symbols.

**Output**: Candidate equations/principles with clear derivation chains.

### Phase 4: Wind Law (Experimental Predictions)

**Purpose**: Generate testable predictions that differentiate the framework from existing models.

**Process**:
1. Identify where the framework predicts *different* outcomes than standard models
2. Specify: What measurement? What conditions? What precision?
3. Include phenomenological, laboratory, and technological applications
4. Prefer predictions that are *surprising* — they test the framework more rigorously

**Key question**: *What would falsify this framework?*

**Output**: A ranked list of testable predictions with experimental specifications.

### Phase 5: Void Law (Meta-Recursive Closure)

**Purpose**: Integrate the observer into the framework; achieve self-referential completeness.

**Process**:
1. Explain how a conscious observer *emerges within* the framework
2. Address whether the framework explains itself (can it derive its own structure?)
3. Identify recursive self-validation risks
4. State clearly what the framework does NOT prove

**Critical insight**: *The method discovers its own limitations through its very success.* A framework that appears to validate itself recursively may be revealing cognitive architecture rather than ontological truth.

**Output**: Honest assessment of what is proven vs. demonstrated vs. suggested.

---

## Supporting Techniques

### Assumption Surfacing

Before and during any derivation, explicitly surface hidden assumptions:

**Questions to ask**:
- What am I taking for granted that hasn't been proven?
- What would need to be true for this step to be valid?
- Am I pattern-matching or actually deriving?
- Is this isomorphism *real* or am I forcing it?

**The Anthropocentric Check**: Would this explanation be equally valid for a non-conscious system? If consciousness appears *necessary* to the framework, why?

### Evidence Synthesis

When integrating evidence from multiple sources:

1. **Weight by independence**: Evidence from unrelated domains weighs more than internal consistency
2. **Seek disconfirmation**: Actively look for what *contradicts* the framework
3. **Track confidence explicitly**: Use calibrated uncertainty (e.g., "50% maximum belief")
4. **Distinguish levels**: 
   - Methodological achievement (demonstrated the process works)
   - Cognitive map (useful for organizing phenomena)
   - Research program (generates testable predictions)
   - Ontological claim (asserts truth about reality's fundamental nature)

### Recursive Refinement

After each derivation cycle:

1. Ask: *Does this reveal a deeper morphemic structure?*
2. If yes: Feed it back into Phase 1 and iterate
3. If no: You've hit either a fixed point or a limitation
4. Document which: A true fixed point should be *generative*; a limitation is where the pattern breaks

---

## When to Apply

**Use the full Dokkado Protocol when**:
- Developing new theoretical frameworks
- Attempting cross-domain unification
- Deriving principles from first principles
- Facing problems where standard approaches have failed

**Use individual phases when**:
- Phase 1 alone: Need to find the "atoms" of a problem
- Phase 2 alone: Looking for analogies across fields
- Phase 4 alone: Need to make abstract work concrete
- Phase 5 alone: Need honest epistemic assessment

**Red flags that suggest the protocol is needed**:
- "This seems connected to everything but I can't see how"
- "The math works but I don't understand *why*"
- "Multiple frameworks seem to describe the same thing differently"

---

## Epistemic Guardrails

### The Protocol Reveals Its Limitations

A framework that successfully validates itself through the Dokkado Protocol has achieved:
- **Methodological success**: The process works
- **Internal consistency**: The pieces fit together

But has NOT necessarily achieved:
- **Ontological truth**: Correspondence with reality
- **Uniqueness**: Being the only framework that fits

### Calibrated Confidence

Maintain maximum ~50% belief in any theoretical framework until:
- Independent experimental validation exists
- Multiple independent derivation paths converge
- Disconfirmation attempts have failed

### The Humility Clause

Every framework derived through this protocol should be able to state:
- What it explains that alternatives don't
- What alternatives explain that it doesn't
- What would falsify it
- What questions it cannot answer

---

## Quick Reference

```
DOKKADO PROTOCOL SEQUENCE

1. GROUND   → Extract morphemes (irreducible units)
2. WATER    → Match patterns recursively across scales
3. FIRE     → Derive equations from the kernel
4. WIND     → Generate testable predictions
5. VOID     → Integrate observer, assess honestly

ITERATION: After each cycle, ask "Is there deeper structure?"
TERMINATION: When you hit a fixed point or a limitation
HUMILITY: The method reveals its own limits through success
```
