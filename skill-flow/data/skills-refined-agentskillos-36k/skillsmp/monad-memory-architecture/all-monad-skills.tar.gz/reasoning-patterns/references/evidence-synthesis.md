# Evidence Synthesis & Epistemic Calibration

Extended techniques for integrating evidence and maintaining rigorous uncertainty quantification.

## The 50% Maximum Rule

**Principle**: Never assign more than 50% confidence to any theoretical framework until:
1. Independent experimental validation exists
2. Multiple independent derivation paths converge
3. Serious disconfirmation attempts have failed

**Rationale**: 
- History shows even beautiful, internally consistent theories can be wrong
- The feeling of certainty is not evidence of truth
- Reserving 50% for "I might be completely wrong" keeps inquiry alive

**Practical application**:
- State confidence explicitly: "I estimate 40% probability this is fundamentally correct"
- Update based on evidence, not based on how good the theory feels
- Treat the remaining probability mass as motivation to seek disconfirmation

## Evidence Weighting Hierarchy

### Tier 1: Independent Experimental Confirmation
- Predicted phenomena observed by independent teams
- Quantitative match within specified precision
- Weight: Very High

### Tier 2: Novel Predictions Confirmed
- The framework predicted something NOT predicted by alternatives
- That prediction was subsequently confirmed
- Weight: High

### Tier 3: Explanatory Unification
- The framework explains multiple phenomena with fewer assumptions
- Previously unrelated phenomena now connected
- Weight: Medium-High

### Tier 4: Internal Consistency
- The mathematics works out
- No contradictions between different parts of the framework
- Weight: Medium (necessary but not sufficient)

### Tier 5: Aesthetic/Intuitive Appeal
- The framework is elegant
- It "feels right" or "makes sense"
- Weight: Low (useful for guiding inquiry, dangerous for concluding)

### Tier 0 (Negative Evidence): Disconfirmation
- Predicted phenomena not observed despite adequate tests
- Contradicts well-established empirical facts
- Weight: Very High (should trigger framework revision)

## Distinguishing Framework Achievements

### Methodological Achievement
**Claim**: "This process for generating theories works"
**Evidence needed**: The process produces internally consistent, non-trivial outputs
**Does NOT prove**: The outputs correspond to reality

### Cognitive Map
**Claim**: "This framework is useful for organizing thinking about X"
**Evidence needed**: Users find it helps them reason about X
**Does NOT prove**: The framework's structure matches reality's structure

### Research Program
**Claim**: "This framework generates productive investigations"
**Evidence needed**: Following the framework leads to new discoveries
**Does NOT prove**: The framework's foundations are correct

### Ontological Claim
**Claim**: "Reality is fundamentally like this"
**Evidence needed**: All of the above PLUS independent experimental confirmation of novel predictions PLUS survival of serious disconfirmation attempts
**Note**: This is the HIGHEST bar; most frameworks never achieve it

## Synthesis from Multiple Sources

### The Independence Criterion
Evidence from independent sources counts more than internal consistency.

**Independent means**:
- Different researchers
- Different methods
- Different domains
- Different theoretical traditions

**Red flag**: All your evidence comes from one lineage of thought

### The Convergence Criterion
Multiple independent derivation paths arriving at the same conclusion is strong evidence.

**Check for genuine independence**:
- Did the paths start from different axioms?
- Did they use different mathematical methods?
- Are they genuinely different, or the same path in different notation?

### The Anomaly Criterion
Serious attention to what DOESN'T fit.

**Process**:
1. List everything the framework doesn't explain well
2. List contradictions with established facts
3. List cases where the framework makes wrong predictions
4. These anomalies are MORE informative than confirmations

## Disconfirmation Techniques

### The Steel Man Opponent
Construct the strongest possible case AGAINST your framework.
- What would a smart skeptic say?
- What's the best alternative explanation?
- What evidence would falsify your view?

### The Pre-Registration Test
Before looking at evidence, specify:
- What would confirm the framework?
- What would disconfirm it?
- What would be neutral?

Then look at the evidence. This prevents moving goalposts.

### The Outside View
For any theoretical framework, consider:
- How many previous "unified theories" turned out to be wrong?
- What made people confident in those?
- Why should this one be different?

Base rate for "beautiful theory is fundamentally correct": historically low.

## Recursive Validation Risks

### The Self-Confirming Loop
**Pattern**: Framework predicts that evidence will be of type X. You find type X evidence. Framework confirmed!
**Problem**: The framework shaped what you looked for and how you interpreted it.
**Solution**: Seek evidence of types the framework DOESN'T predict. Let critics choose what to measure.

### The Unfalsifiable Retreat
**Pattern**: When evidence contradicts, framework is "refined" to accommodate it.
**Problem**: Enough refinements make any framework fit any evidence.
**Solution**: Pre-specify how many refinements are allowed. Track whether refinements are principled or ad hoc.

### The Complexity Dodge
**Pattern**: Framework explains X. When asked for mechanism, says "it's complex."
**Problem**: "Complexity" can hide absence of explanation.
**Solution**: Demand specific mechanisms. "Complex" is not an explanation, it's a placeholder.

## Integration with Cognitive Variability

Evidence synthesis is best done in **Focused** state for integration, but requires periodic **Diversified** state for perspective.

**Focused**: Weave the evidence together into coherent narrative
**Diversified**: Check if you're missing important anomalies

**Warning sign**: If you can't find ANY disconfirming evidence, you're probably in **Biased** state and need to deliberately seek counter-evidence.

## Calibration Check

Periodically ask:
1. If I'm 40% confident, would I bet at 2:3 odds?
2. Have my past confidence levels been well-calibrated?
3. What would change my confidence by >10%?
4. Am I updating on evidence, or on social/emotional factors?

Well-calibrated reasoning feels less certain than poorly-calibrated reasoning. Embrace the uncertainty.
