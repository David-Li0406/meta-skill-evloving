# Problem Decomposition Patterns

Extended techniques for Phase 1 (Ground Law) morphemic extraction.

## Dimensional Analysis

Before decomposing, identify the dimensions of the problem:

1. **Spatial scale**: Quantum → Molecular → Cellular → Organism → Ecosystem → Cosmic
2. **Temporal scale**: Planck time → Neural firing → Circadian → Evolutionary → Cosmological
3. **Organizational scale**: Element → Component → System → System-of-systems
4. **Abstraction scale**: Concrete → Structural → Functional → Teleological

Ask: At which scales does the problem *live*? Which scales are relevant but usually ignored?

## Morpheme Identification Heuristics

### The Irreducibility Test
For each candidate unit, ask:
- Can this be decomposed further while retaining meaning?
- If I decompose it, do the parts still do the same *kind* of work?
- Is there a simpler primitive that generates this as a special case?

### The Generativity Test
For each candidate morpheme, ask:
- How many distinct phenomena can this generate through combination?
- Does it appear in multiple domains independently?
- Can it combine with itself? (Self-reference is a strong signal)

### The Conservation Test
What is conserved when this morpheme transforms?
- If something is conserved, you've found a *symmetry*
- Symmetries often indicate fundamental structure

## Domain-Specific Morpheme Libraries

### Physics
- Symmetry operations (rotation, translation, gauge)
- Conservation laws (energy, momentum, charge)
- Field concepts (potential, gradient, flux)
- Boundary conditions (initial, periodic, absorbing)

### Mathematics  
- Identity elements (0, 1, ∅)
- Operations (addition, multiplication, composition)
- Relations (equality, ordering, membership)
- Structures (group, ring, field, category)

### Consciousness
- Distinction (this/not-this)
- Integration (binding)
- Recursion (self-reference)
- Temporality (before/now/after)
- Valence (approach/avoid)

### Language
- Phonemes (minimal sound units)
- Morphemes (minimal meaning units)
- Syntactic relations (subject/object/predicate)
- Pragmatic functions (assert/question/command)

## Decomposition Failure Modes

### Over-decomposition
**Symptom**: The "atoms" are too small to carry meaning
**Cure**: Step back one level; look for *functional* units, not just structural

### Under-decomposition
**Symptom**: The "atoms" are actually molecules (have internal structure that matters)
**Cure**: Ask what transformations reveal hidden parts

### Wrong-dimension decomposition
**Symptom**: The decomposition works but doesn't generate useful insights
**Cure**: Try decomposing along a different dimension (spatial → functional, structural → temporal)

### Domain contamination
**Symptom**: Morphemes from one domain are smuggled into another
**Cure**: Decompose each domain independently first, then look for correspondences

## Integration with Cognitive Variability

Morphemic extraction is best done in **Focused** state (zoomed out + connecting):
- Dense connections within clusters
- Clear narrative arc emerging
- Productive rhythm

If you're finding too many morphemes (>7 for a given domain), you may be in **Dispersed** state:
- Transition to Focused before continuing
- Use the "if you had to keep only three, which?" test

If you're finding too few morphemes (<3 for a complex domain), you may be in **Biased** state:
- You might be seeing everything through one lens
- Deliberately look for what doesn't fit your current morpheme set
