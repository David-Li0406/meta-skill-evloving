# Cross-Domain Pattern Matching

Extended techniques for Phase 2 (Water Law) recursive pattern matching.

## Isomorphism vs Analogy vs Metaphor

**Isomorphism**: Structural identity — same operations, same relations, different elements
- Example: Group structure in rotations and in modular arithmetic
- Test: Can you define a bijection that preserves all operations?

**Analogy**: Partial structural similarity — some operations correspond, others don't
- Example: Electric circuits and hydraulic systems (voltage~pressure, current~flow)
- Test: Which operations correspond? Which break the mapping?

**Metaphor**: Suggestive similarity — points toward something without formal correspondence
- Example: "The mind is like a computer"
- Test: Does it generate predictions, or just organize intuitions?

**For theoretical work**: Prefer isomorphisms. Accept analogies with explicit limits. Use metaphors only for exploration, not derivation.

## The Scale-Bridging Method

### Step 1: Identify Scale-Specific Descriptions
For each scale (micro, meso, macro), describe:
- What are the relevant entities?
- What are the relevant interactions?
- What are the relevant observables?

### Step 2: Find Coarse-Graining Operations
How do you get from micro to meso? Meso to macro?
- Averaging? Renormalization?
- What information is lost?
- What structures are preserved?

### Step 3: Look for Scale-Invariant Patterns
What appears the same at multiple scales?
- Self-similarity (fractals)
- Universal scaling laws
- Conserved ratios (often involving φ, π, or e)

### Step 4: Identify Scale-Breaking Points
Where does the pattern *stop* working?
- Phase transitions
- Emergence thresholds
- Symmetry breaking

Scale-breaking is as informative as scale-invariance.

## Recursion Kernel Identification

The recursion kernel is the minimal pattern that generates the observed structure through self-application.

### Candidate Kernel Tests

**Self-Application Test**: Does applying the pattern to itself produce:
- More of the same pattern? (Good: suggests true recursion)
- Something different? (Check if the difference is meaningful)
- Divergence/collapse? (Pattern is not stable)

**Universality Test**: Does the same kernel appear in:
- At least 3 independent domains?
- Domains with different underlying substrates?
- Both abstract and physical systems?

**Generativity Test**: Can you derive the target phenomena by:
- Starting from the kernel alone?
- Applying only operations contained in the kernel?
- Without adding external information?

### Common Recursion Kernels

**Self-Reference**: X is defined in terms of X
- Appears in: consciousness, fractals, Gödel sentences, φ
- Signature: X = f(X) for some f

**Iteration**: Applying the same operation repeatedly
- Appears in: growth, computation, evolution, e
- Signature: X_{n+1} = g(X_n)

**Boundary/Bulk**: Structure determined by its interface
- Appears in: holography, membranes, consciousness/reality interface, π
- Signature: Interior determined by boundary conditions

**Unity/Multiplicity**: One becomes many, many become one
- Appears in: quantum measurement, attention, democracy
- Signature: 1 ↔ N transitions

## Pattern Pathologies

### Apophenia (False Pattern Detection)
**Symptom**: Everything seems connected; you can find any pattern you're looking for
**Cure**: 
- Specify the pattern BEFORE looking
- Count misses, not just hits
- Test on data you didn't use to find the pattern

### Procrustean Fitting
**Symptom**: Pattern "works" but requires stretching definitions or ignoring cases
**Cure**:
- List everything the pattern DOESN'T explain
- If exceptions exceed 30%, the pattern isn't capturing reality

### Confirmation Cascade
**Symptom**: Each confirmation makes you more certain, but you're only looking for confirmations
**Cure**:
- Actively seek disconfirmation
- Ask: "What would convince me this is wrong?"
- Weight disconfirmations higher than confirmations

### Premature Abstraction
**Symptom**: You've found a pattern but don't understand WHY it's there
**Cure**:
- Don't move to Phase 3 until you can explain the mechanism
- "It just works" is not sufficient for theoretical frameworks

## Integration with Cognitive Variability

Pattern matching operates best in **Diversified** state (zoomed out + exploring):
- Multiple distinct clusters visible
- Gaps between clusters are opportunity spaces
- Polysingular perspective

If you're finding only one pattern everywhere (**Biased** state):
- Force yourself to find a COUNTER-pattern
- What would the opposite pattern look like?

If you're drowning in possible patterns (**Dispersed** state):
- Rank by number of independent domains where pattern appears
- Cut anything that appears in fewer than 3 domains
